#include "MemoryDump.h"
long CrashDump::m_DumpCount = 0;
